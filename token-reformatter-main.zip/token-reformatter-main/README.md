# token-reformatter
yes literally token reformatter

just put tokens in tokens.txt and done
